import SwiftUI
import AudioToolbox

// MARK: - Models
struct Game: Identifiable, Hashable {
    let id: Int
    let name: String
    let description: String
    let icon: String
    
    static func == (lhs: Game, rhs: Game) -> Bool {
        lhs.id == rhs.id
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}

struct GameScore: Identifiable, Codable {
    let id: UUID
    let gameName: String
    let score: Int
    let date: Date
    
    init(id: UUID = UUID(), gameName: String, score: Int, date: Date) {
        self.id = id
        self.gameName = gameName
        self.score = score
        self.date = date
    }
}

struct Fact {
    let title: String
    let content: String
    let icon: String
}

// MARK: - View Models
@MainActor
class GameScoreManager: ObservableObject {
    @Published var scores: [GameScore] = []
    
    func addScore(_ score: Int, for gameName: String) {
        let newScore = GameScore(gameName: gameName, score: score, date: Date())
        scores.append(newScore)
    }
    
    func getTotalScore(for gameName: String) -> Int {
        scores.filter { $0.gameName == gameName }.map { $0.score }.reduce(0, +)
    }
    
    func getAllTimeTotal() -> Int {
        scores.map { $0.score }.reduce(0, +)
    }
    
    // Save high scores and achievements
    func saveGameData() {
        if let encoded = try? JSONEncoder().encode(scores) {
            UserDefaults.standard.set(encoded, forKey: "gameScores")
        }
    }
}

@MainActor
class GameState: ObservableObject {
    @Published var timeRemaining = 60
    @Published var score = 0
    @Published var isActive = false
    @Published var isTargetActive = false
    
    func endGame() {
        isActive = false
    }
}

// MARK: - Supporting Views
struct GameCard: View {
    let game: Game
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        HStack(spacing: 20) {
            Image(systemName: game.icon)
                .font(.system(size: 30))
                .foregroundColor(colorScheme == .dark ? .white : .purple)
                .frame(width: 60, height: 60)
                .background(
                    Circle()
                        .fill(colorScheme == .dark ?
                              Color.purple.opacity(0.3) :
                                Color.purple.opacity(0.1))
                )
            
            VStack(alignment: .leading, spacing: 5) {
                Text(game.name)
                    .font(.title3)
                    .fontWeight(.semibold)
                    .foregroundColor(colorScheme == .dark ? .white : .primary)
                
                Text(game.description)
                    .font(.subheadline)
                    .foregroundColor(colorScheme == .dark ? .white.opacity(0.7) : .secondary)
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .foregroundColor(colorScheme == .dark ? .white : .purple)
                .font(.system(size: 14, weight: .semibold))
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 15)
                .fill(colorScheme == .dark ?
                      Color.black.opacity(0.3) :
                        Color.white)
                .shadow(
                    color: colorScheme == .dark ?
                    Color.purple.opacity(0.3) :
                        Color.black.opacity(0.1),
                    radius: 5,
                    x: 0,
                    y: 2
                )
        )
        .padding(.horizontal)
        .accessibilityLabel("\(game.name)")
        .accessibilityHint("\(game.description). Tap to play.")
    }
}

// Update GameHeaderView
struct GameHeaderView: View {
    let gameName: String
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        Text(gameName)
            .font(.title2.bold())
            .foregroundStyle(
                LinearGradient(
                    colors: colorScheme == .dark ?
                    [.purple.opacity(0.8), .blue.opacity(0.8)] :
                        [.purple, .blue],
                    startPoint: .leading,
                    endPoint: .trailing
                )
            )
            .padding(.leading, 8)  // Adjust left padding
            .frame(maxWidth: .infinity, alignment: .leading)
    }
}

// MARK: - Games View
struct GamesView: View {
    @State private var currentQuoteIndex = 0
    private let timer = Timer.publish(every: 5.0, on: .main, in: .common).autoconnect()
    @Environment(\.colorScheme) private var colorScheme
    
    let quotes = [
        "Train your mind, change your life",
        "Every challenge is an opportunity to grow",
        "Your potential is limitless",
        "Small steps, big improvements",
        "Exercise your brain daily"
    ]
    
    let games = [
        Game(id: 1, name: "Memory Match", description: "Test and improve your memory", icon: "brain"),
        Game(id: 2, name: "Speed Logic", description: "Enhance your logical thinking", icon: "bolt"),
        Game(id: 3, name: "Pattern Match", description: "Improve focus through pattern recognition", icon: "puzzlepiece.fill"),
        Game(id: 4, name: "Quick React", description: "Test your reaction time", icon: "timer")
    ]
    
    var body: some View {
        ScrollView {
            VStack(spacing: 25) {
                // Header with gradient and quote
                VStack(spacing: 15) {
                    Text("Mind Gym")
                        .font(.system(size: 40, weight: .bold))
                        .foregroundStyle(
                            LinearGradient(
                                colors: colorScheme == .dark ?
                                [.purple.opacity(0.8), .blue.opacity(0.8)] :
                                    [.purple, .blue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                    
                    Text(quotes[currentQuoteIndex])
                        .font(.title3)
                        .italic()
                        .foregroundColor(colorScheme == .dark ? .white.opacity(0.8) : .secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .onReceive(timer) { _ in
                            withAnimation {
                                currentQuoteIndex = (currentQuoteIndex + 1) % quotes.count
                            }
                        }
                }
                .padding(.vertical, 30)
                .frame(maxWidth: .infinity)
                .background(
                    RoundedRectangle(cornerRadius: 25)
                        .fill(
                            LinearGradient(
                                colors: colorScheme == .dark ?
                                [Color.purple.opacity(0.3), Color.blue.opacity(0.3)] :
                                    [Color.purple.opacity(0.1), Color.blue.opacity(0.1)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                )
                .padding(.horizontal)
                
                ForEach(games) { game in
                    NavigationLink(destination: GameDetailView(game: game)) {
                        GameCard(game: game)
                    }
                }
            }
            .padding(.vertical)
        }
        .navigationBarHidden(true)
    }
}
var body: some View {
        Text("Games Page")
            .font(.largeTitle)
            .bold()
            .navigationTitle("Games")
    }


// MARK: - Game Detail View
struct GameDetailView: View {
    let game: Game
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var colorScheme
    @EnvironmentObject var scoreManager: GameScoreManager
    @State private var isGameStarted = false
    @State private var selectedGame: Game?
    
    // Animation states
    @State private var iconScale = 0.5
    @State private var iconRotation = 0.0
    @State private var titleOffset: CGFloat = -50
    @State private var descriptionOffset: CGFloat = 50
    @State private var buttonScale = 0.1
    @State private var showingPulse = false
    @State private var showTutorial = false
    @State private var hasSeenTutorial = false
    
    private var gameTutorial: GameTutorial {
        switch game.name {
        case "Memory Match":
            return GameTutorial(
                title: "How to Play Memory Match",
                steps: [
                    .init(image: "brain", title: "Remember", description: "Study the cards when they're revealed"),
                    .init(image: "hand.tap", title: "Match", description: "Tap cards to find matching pairs"),
                    .init(image: "stopwatch", title: "Be Quick", description: "Match all pairs before time runs out")
                ]
            )
        // Add other game tutorials similarly
        default:
            return GameTutorial(title: "", steps: [])
        }
    }
    
    @State private var selectedDifficulty: GameDifficulty = .easy
    
    private func getDifficultySettings() -> (timeLimit: Int, targetScore: Int) {
        switch selectedDifficulty {
        case .easy:
            return (timeLimit: 60, targetScore: 100)
        case .medium:
            return (timeLimit: 45, targetScore: 150)
        case .hard:
            return (timeLimit: 30, targetScore: 200)
        }
    }
    
    @Namespace private var animation
    
    var body: some View {
        VStack {
            if !isGameStarted {
                VStack(spacing: 25) {
                    // Header
                    HStack {
                        Button(action: { dismiss() }) {
                            Image(systemName: "xmark.circle.fill")
                                .font(.title2)
                                .foregroundColor(.purple)
                                .accessibilityLabel("Close")
                        }
                        .padding()
                        Spacer()
                    }
                    
                    // Game Icon with animations
                    ZStack {
                        // Pulse effect
                        Circle()
                            .fill(Color.purple.opacity(0.2))
                            .frame(width: 120, height: 120)
                            .scaleEffect(showingPulse ? 1.2 : 0.8)
                            .opacity(showingPulse ? 0.0 : 0.5)
                            .animation(
                                .easeInOut(duration: 1.5)
                                .repeatForever(autoreverses: false),
                                value: showingPulse
                            )
                        
                        // Secondary pulse
                        Circle()
                            .fill(Color.purple.opacity(0.2))
                            .frame(width: 120, height: 120)
                            .scaleEffect(showingPulse ? 1.1 : 0.9)
                            .opacity(showingPulse ? 0.2 : 0.4)
                            .animation(
                                .easeInOut(duration: 1.5)
                                .repeatForever(autoreverses: false)
                                .delay(0.5),
                                value: showingPulse
                            )
                        
                        // Main icon
                        Image(systemName: game.icon)
                            .font(.system(size: 60))
                            .foregroundColor(colorScheme == .dark ? .white : .purple)
                            .frame(width: 100, height: 100)
                            .background(
                                Circle()
                                    .fill(colorScheme == .dark ?
                                          Color.purple.opacity(0.3) :
                                            Color.purple.opacity(0.1))
                            )
                            .scaleEffect(iconScale)
                            .rotationEffect(.degrees(iconRotation))
                    }
                    .padding()
                    
                    // Game Title and Description
                    VStack(spacing: 15) {
                        Text(game.name)
                            .font(.title)
                            .bold()
                            .foregroundColor(colorScheme == .dark ? .white : .primary)
                            .offset(y: titleOffset)
                        
                        // Game benefits
                        VStack(spacing: 12) {
                            Text("Benefits:")
                                .font(.headline)
                                .foregroundColor(colorScheme == .dark ? .white : .primary)
                            
                            ForEach(getBenefits(), id: \.self) { benefit in
                                HStack {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(.green)
                                    Text(benefit)
                                        .foregroundColor(colorScheme == .dark ? .white.opacity(0.8) : .secondary)
                                }
                                .offset(x: descriptionOffset)
                            }
                        }
                        .padding(.vertical)
                        
                        Text(getDetailedDescription())
                            .font(.body)
                            .foregroundColor(colorScheme == .dark ? .white.opacity(0.8) : .secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal)
                            .offset(y: descriptionOffset)
                    }
                    
                    Spacer()
                    
                    // Add difficulty selector before start button
                    GradientSegmentedControl(selection: $selectedDifficulty)
                        .padding()
                    
                    // Start Game Button
                    Button(action: {
                        withAnimation(.spring()) {
                            isGameStarted = true
                        }
                    }) {
                        Text("Start Game")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(
                                LinearGradient(
                                    colors: [.purple, .blue],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .cornerRadius(10)
                            .shadow(color: .purple.opacity(0.3), radius: 5)
                    }
                    .padding()
                    .scaleEffect(buttonScale)
                }
                .onAppear {
                    // Trigger animations
                    withAnimation(.spring(response: 0.6, dampingFraction: 0.6)) {
                        iconScale = 1.0
                        iconRotation = 360
                    }
                    
                    withAnimation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.2)) {
                        titleOffset = 0
                    }
                    
                    withAnimation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.4)) {
                        descriptionOffset = 0
                    }
                    
                    withAnimation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.6)) {
                        buttonScale = 1.0
                    }
                    
                    showingPulse = true
                }
            } else {
                gameContent
                    .transition(.asymmetric(
                        insertion: .scale.combined(with: .opacity),
                        removal: .scale.combined(with: .opacity)
                    ))
            }
        }
        .navigationBarBackButtonHidden(true)
        .onAppear {
            // Load the value when the view appears
            hasSeenTutorial = UserDefaults.standard.bool(forKey: "tutorial_\(game.name)")
        }
        .sheet(isPresented: $showTutorial) {
            TutorialView(tutorial: gameTutorial) {
                // Save the value when completing tutorial
                hasSeenTutorial = true
                UserDefaults.standard.set(true, forKey: "tutorial_\(game.name)")
                showTutorial = false
            }
        }
        .animation(.spring(response: 0.6, dampingFraction: 0.8), value: isGameStarted)
    }
    
    // Helper function to get game-specific benefits
    private func getBenefits() -> [String] {
        switch game.name {
        case "Memory Match":
            return ["Enhanced memory retention", "Pattern recognition", "Visual memory"]
        case "Speed Logic":
            return ["Faster problem solving", "Mental arithmetic", "Logical thinking"]
        case "Pattern Match":
            return ["Pattern recognition", "Visual memory", "Sustained attention"]
        case "Quick React":
            return ["Lightning-fast reflexes", "Decision making", "Mental alertness"]
        default:
            return []
        }
    }
    
    // Helper function to get detailed description
    private func getDetailedDescription() -> String {
        switch game.name {
        case "Memory Match":
            return "Faster you match, higher the score."
        case "Speed Logic":
            return "Solve mathematical puzzles against the clock."
        case "Pattern Match":
            return "Improve your focus by matching patterns."
        case "Quick React":
            return "Test your reactive ability."
        default:
            return game.description
        }
    }
    
    @ViewBuilder
    private var gameContent: some View {
        switch game.name {
        case "Memory Match":
            MemoryMatchGame(selectedGame: $selectedGame)
                .environmentObject(scoreManager)
                .onDisappear {
                    if let score = scoreManager.scores.last?.score {
                        scoreManager.addScore(score, for: "Memory Match")
                    }
                }
        case "Speed Logic":
            SpeedLogicGame(selectedGame: $selectedGame)
                .environmentObject(scoreManager)
                .onDisappear {
                    if let score = scoreManager.scores.last?.score {
                        scoreManager.addScore(score, for: "Speed Logic")
                    }
                }
        case "Pattern Match":
            PatternMatchGame(selectedGame: $selectedGame)
                .environmentObject(scoreManager)
                .onDisappear {
                    if let score = scoreManager.scores.last?.score {
                        scoreManager.addScore(score, for: "Pattern Match")
                    }
                }
        case "Quick React":
            QuickReactGame(selectedGame: $selectedGame)
                .environmentObject(scoreManager)
                .onDisappear {
                    if let score = scoreManager.scores.last?.score {
                        scoreManager.addScore(score, for: "Quick React")
                    }
                }
        default:
            Text("Game not available")
        }
    }
}

// MARK: - Memory Match Game
struct MemoryMatchGame: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var scoreManager: GameScoreManager
    @StateObject private var gameState = GameState()
    @State private var cards = [Card]()
    @State private var flippedCards = Set<Int>()
    @State private var matchedCards = Set<Int>()
    @State private var moves = 0
    @State private var showGameOver = false
    @State private var isPreviewMode = false
    @State private var buttonScale = 1.0
    @State private var buttonRotation = 0.0
    @Binding var selectedGame: Game?
    @State private var selectedDifficulty: GameDifficulty = .easy
    
    struct Card: Identifiable {
        let id: Int
        let symbol: String
    }
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var isInDailyChallenge: Bool {
        scoreManager.scores.isEmpty
    }
    
    var gameOverAlert: some View {
        VStack(spacing: 20) {
            Text("Game Complete!")
                .font(.title2)
                .bold()
                .foregroundColor(.purple)
            
            Text("Score: \(gameState.score)")
                .font(.title3)
                .foregroundColor(.secondary)
            
            HStack(spacing: 20) {
                Button(action: { dismiss() }) {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                        Text("Exit")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 120)
                    .padding()
                    .background(Color.red.opacity(0.8))
                    .cornerRadius(15)
                }
                .scaleEffect(buttonScale)
                
                Button(action: {
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                        buttonScale = 1.2
                        buttonRotation += 360
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        if isInDailyChallenge {
                            scoreManager.addScore(gameState.score, for: "Memory Match")
                            dismiss()
                        } else {
                            resetGame()
                            showGameOver = false
                        }
                    }
                    
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.6).delay(0.3)) {
                        buttonScale = 1.0
                    }
                }) {
                    HStack {
                        Image(systemName: isInDailyChallenge ? "arrow.right.circle.fill" : "arrow.clockwise.circle.fill")
                        Text(isInDailyChallenge ? "Next Game" : "Play Again")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 120)
                    .padding()
                    .background(
                        LinearGradient(
                            colors: isInDailyChallenge ? [.blue, .purple] : [.green, .blue],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .cornerRadius(15)
                }
                .scaleEffect(buttonScale)
                .rotationEffect(.degrees(buttonRotation))
            }
        }
        .padding(30)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.2), radius: 10)
    }
    
    var body: some View {
        VStack {
            // Navigation and Title
            HStack {
                Button(action: { dismiss() }) {
                    Image(systemName: "arrow.left.circle.fill")
                        .font(.title2)
                        .foregroundColor(.purple)
                }
                .padding(.horizontal)  // Add horizontal padding
                
                GameHeaderView(gameName: "Memory Match")
            }
            .padding(.vertical, 8)  // Add vertical padding
            
            // Score and moves counter
            HStack {
                Text("Score: \(gameState.score)")
                Spacer()
                Text("Moves: \(moves)")
            }
            .padding()
            
            // Game grid
            LazyVGrid(columns: columns, spacing: 10) {
                ForEach(cards) { card in
                    CardView(
                        symbol: card.symbol,
                        isFlipped: flippedCards.contains(card.id) || isPreviewMode,
                        isMatched: matchedCards.contains(card.id)
                    )
                    .onTapGesture {
                        if !isPreviewMode {
                            withAnimation {
                                handleCardTap(card)
                            }
                        }
                    }
                }
            }
            .padding()
            
            if !gameState.isActive {
                GradientSegmentedControl(selection: $selectedDifficulty)
                    .padding()
                
                Button("Start Game") {
                    startGame()
                }
                .font(.title2)
                .foregroundColor(.white)
                .padding()
                .background(Color.purple)
                .cornerRadius(10)
            }
        }
        .overlay {
            if showGameOver {
                Color.black.opacity(0.5)
                    .ignoresSafeArea()
                    .overlay(gameOverAlert)
                    .transition(.opacity)
            }
        }
        .onAppear {
            startGame()
        }
    }
    
    private func startGame() {
        // Update to use difficulty settings
        let settings = getDifficultySettings()
        gameState.timeRemaining = settings.timeLimit
        gameState.score = 0
        moves = 0
        gameState.isActive = true
        isPreviewMode = true
        
        let symbols = ["🧠", "⭐️", "🎯", "💡", "🎲", "🔮", "🎨", "🎭"]
        let pairs = (symbols + symbols).shuffled()
        cards = pairs.enumerated().map { Card(id: $0, symbol: $1) }
        flippedCards.removeAll()
        matchedCards.removeAll()
        
        // Show cards for 4 seconds then hide them
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 4_000_000_000)
            withAnimation {
                isPreviewMode = false
            }
        }
    }
    
    private func handleCardTap(_ card: Card) {
        if flippedCards.contains(card.id) || matchedCards.contains(card.id) {
            return
        }
        
        flippedCards.insert(card.id)
        
        if flippedCards.count == 2 {
            moves += 1
            let flippedPair = cards.filter { flippedCards.contains($0.id) }
            
            if flippedPair[0].symbol == flippedPair[1].symbol {
                matchedCards.formUnion(flippedCards)
                gameState.score += 10
                flippedCards.removeAll()
                
                if matchedCards.count == cards.count {
                    handleGameCompletion()
                }
            } else {
                Task { @MainActor in
                    try? await Task.sleep(nanoseconds: 1_000_000_000)
                    withAnimation {
                        flippedCards.removeAll()
                    }
                }
                if gameState.score > 0 {
                    gameState.score -= 1
                }
            }
        }
    }
    
    private func handleGameCompletion() {
        SoundManager.shared.playSuccess()
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
        
        // Celebration animation
        withAnimation(.spring(response: 0.6, dampingFraction: 0.7)) {
            showGameOver = true
        }
        
        // Confetti effect
        if gameState.score > getDifficultySettings().targetScore {
            // Add confetti celebration
            withAnimation {
                // Implement confetti view
            }
        }
        
        if isInDailyChallenge {
            scoreManager.addScore(gameState.score, for: "Memory Match")
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                dismiss()
            }
        }
    }
    
    private func resetGame() {
        gameState.score = 0
        moves = 0
        gameState.isActive = true
        isPreviewMode = true
    }
    
    // Add this function
    private func getDifficultySettings() -> (timeLimit: Int, targetScore: Int) {
        switch selectedDifficulty {
        case .easy:
            return (timeLimit: 60, targetScore: 100)
        case .medium:
            return (timeLimit: 45, targetScore: 150)
        case .hard:
            return (timeLimit: 30, targetScore: 200)
        }
    }
}

struct CardView: View {
    let symbol: String
    let isFlipped: Bool
    let isMatched: Bool
    
    var body: some View {
        ZStack {
            if isFlipped || isMatched {
                RoundedRectangle(cornerRadius: 10)
                    .fill(isMatched ? Color.green.opacity(0.5) : Color.white)
                    .overlay(
                        Text(symbol)
                            .font(.system(size: 30))
                    )
            } else {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.purple)
            }
        }
        .frame(height: 80)
        .rotation3DEffect(
            .degrees(isFlipped ? 180 : 0),
            axis: (x: 0.0, y: 1.0, z: 0.0)
        )
    }
}

// MARK: - Quick React Game
struct QuickReactGame: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var scoreManager: GameScoreManager
    @StateObject private var gameState = GameState()
    @State private var startTime: Date?
    @State private var reactionTime: Double?
    @State private var bestTime: Double?
    @State private var falseStarts = 0
    @State private var roundsPlayed = 0
    @State private var showGameOver = false
    @Binding var selectedGame: Game?
    @State private var buttonScale = 1.0
    @State private var buttonRotation = 0.0
    
    enum GamePhase {
        case waiting, getReady, react, tooEarly, results
    }
    
    @State private var currentPhase = GamePhase.waiting
    
    var isInDailyChallenge: Bool {
        scoreManager.scores.isEmpty
    }
    
    var gameOverAlert: some View {
        VStack(spacing: 20) {
            Text("Game Complete!")
                .font(.title2)
                .bold()
                .foregroundColor(.purple)
            
            Text("Score: \(gameState.score)")
                .font(.title3)
                .foregroundColor(.secondary)
            
            HStack(spacing: 20) {
                Button(action: { dismiss() }) {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                        Text("Exit")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 120)
                    .padding()
                    .background(Color.red.opacity(0.8))
                    .cornerRadius(15)
                }
                .scaleEffect(buttonScale)
                
                Button(action: {
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                        buttonScale = 1.2
                        buttonRotation += 360
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        if isInDailyChallenge {
                            scoreManager.addScore(gameState.score, for: "Quick React")
                            dismiss()
                        } else {
                            resetGame()
                            showGameOver = false
                        }
                    }
                    
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.6).delay(0.3)) {
                        buttonScale = 1.0
                    }
                }) {
                    HStack {
                        Image(systemName: isInDailyChallenge ? "arrow.right.circle.fill" : "arrow.clockwise.circle.fill")
                        Text(isInDailyChallenge ? "Next Game" : "Play Again")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 120)
                    .padding()
                    .background(
                        LinearGradient(
                            colors: isInDailyChallenge ? [.blue, .purple] : [.green, .blue],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .cornerRadius(15)
                }
                .scaleEffect(buttonScale)
                .rotationEffect(.degrees(buttonRotation))
            }
        }
        .padding(30)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.2), radius: 10)
    }
    
    var body: some View {
        VStack {
            // Navigation and Title
            HStack {
                Button(action: { dismiss() }) {
                    Image(systemName: "arrow.left.circle.fill")
                        .font(.title2)
                        .foregroundColor(.purple)
                }
                .padding(.horizontal)  // Add horizontal padding
                
                GameHeaderView(gameName: "Quick React")
            }
            .padding(.vertical, 8)  // Add vertical padding
            
            // Score display
            HStack {
                VStack {
                    Text("Best Time")
                        .font(.headline)
                    Text(bestTime.map { String(format: "%.3fs", $0) } ?? "-")
                        .font(.title)
                }
                
                Spacer()
                
                VStack {
                    Text("Score")
                        .font(.headline)
                    Text("\(gameState.score)")
                        .font(.title)
                }
                
                Spacer()
                
                VStack {
                    Text("False Starts")
                        .font(.headline)
                    Text("\(falseStarts)")
                        .font(.title)
                }
            }
            .padding()
            
            Spacer()
            
            // Game area
            Circle()
                .fill(backgroundColor)
                .frame(width: 200, height: 200)
                .overlay(
                    Text(messageText)
                        .font(.title)
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                )
                .onTapGesture(perform: handleTap)
            
            Spacer()
        }
        .overlay {
            if showGameOver {
                Color.black.opacity(0.5)
                    .ignoresSafeArea()
                    .overlay(gameOverAlert)
                    .transition(.opacity)
            }
        }
    }
    
    private var backgroundColor: Color {
        switch currentPhase {
        case .waiting: return .purple
        case .getReady: return .orange
        case .react: return .green
        case .tooEarly: return .red
        case .results: return .blue
        }
    }
    
    private var messageText: String {
        switch currentPhase {
        case .waiting: return "Tap to Start"
        case .getReady: return "Wait for Green"
        case .react: return "TAP NOW!"
        case .tooEarly: return "Too Early!"
        case .results:
            if let time = reactionTime {
                return String(format: "%.3f seconds", time)
            }
            return "Tap to continue"
        }
    }
    
    @MainActor
    private func startGame() {
        currentPhase = .getReady
        let waitTime = Double.random(in: 1.5...3.5)
        
        Task {
            try? await Task.sleep(nanoseconds: UInt64(waitTime * 1_000_000_000))
            if currentPhase == .getReady {
                currentPhase = .react
                startTime = Date()
            }
        }
    }
    
    @MainActor
    private func handleTap() {
        switch currentPhase {
        case .waiting:
            startGame()
            
        case .getReady:
            currentPhase = .tooEarly
            falseStarts += 1
            if gameState.score >= 5 {
                gameState.score -= 5
            }
            Task {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                currentPhase = .waiting
            }
            
        case .react:
            if let start = startTime {
                let time = Date().timeIntervalSince(start)
                reactionTime = time
                if bestTime == nil || time < bestTime! {
                    bestTime = time
                }
                
                // Award points based on reaction time
                if time <= 0.2 { gameState.score += 30 }
                else if time <= 0.3 { gameState.score += 25 }
                else if time <= 0.4 { gameState.score += 20 }
                else if time <= 0.5 { gameState.score += 15 }
                else if time <= 0.7 { gameState.score += 10 }
                else { gameState.score += 5 }
                
                currentPhase = .results
                roundsPlayed += 1
                
                if roundsPlayed >= 5 {
                    showGameOver = true
                    handleGameCompletion()
                } else {
                    Task {
                        try? await Task.sleep(nanoseconds: 2_000_000_000)
                        currentPhase = .waiting
                    }
                }
            }
            
        case .tooEarly:
            break
            
        case .results:
            if roundsPlayed >= 5 {
                showGameOver = true
            } else {
                currentPhase = .waiting
            }
        }
    }
    
    private func handleGameCompletion() {
        SoundManager.shared.playSuccess()
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
        showGameOver = true
        if isInDailyChallenge {
            scoreManager.addScore(gameState.score, for: "Quick React")
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                dismiss()
            }
        }
    }
    
    private func resetGame() {
        currentPhase = .waiting
        reactionTime = nil
        gameState.score = 0
        falseStarts = 0
        roundsPlayed = 0
    }
}

// MARK: - Speed Logic Game
struct SpeedLogicGame: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var scoreManager: GameScoreManager
    @StateObject private var gameState = GameState()
    @State private var currentProblem = ""
    @State private var correctAnswer = 0
    @State private var options: [Int] = []
    @State private var showGameOver = false
    @Binding var selectedGame: Game?
    @State private var buttonScale = 1.0
    @State private var buttonRotation = 0.0
    @State private var selectedDifficulty: GameDifficulty = .easy
    
    private func getDifficultySettings() -> (timeLimit: Int, targetScore: Int) {
        switch selectedDifficulty {
        case .easy:
            return (timeLimit: 60, targetScore: 100)
        case .medium:
            return (timeLimit: 45, targetScore: 150)
        case .hard:
            return (timeLimit: 30, targetScore: 200)
        }
    }
    
    var isInDailyChallenge: Bool {
        scoreManager.scores.isEmpty
    }
    
    var gameOverAlert: some View {
        VStack(spacing: 20) {
            Text("Game Complete!")
                .font(.title2)
                .bold()
                .foregroundColor(.purple)
            
            Text("Score: \(gameState.score)")
                .font(.title3)
                .foregroundColor(.secondary)
            
            HStack(spacing: 20) {
                Button(action: { dismiss() }) {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                        Text("Exit")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 120)
                    .padding()
                    .background(Color.red.opacity(0.8))
                    .cornerRadius(15)
                }
                .scaleEffect(buttonScale)
                
                Button(action: {
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                        buttonScale = 1.2
                        buttonRotation += 360
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        if isInDailyChallenge {
                            scoreManager.addScore(gameState.score, for: "Speed Logic")
                            dismiss()
                        } else {
                            startGame()
                            showGameOver = false
                        }
                    }
                    
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.6).delay(0.3)) {
                        buttonScale = 1.0
                    }
                }) {
                    HStack {
                        Image(systemName: isInDailyChallenge ? "arrow.right.circle.fill" : "arrow.clockwise.circle.fill")
                        Text(isInDailyChallenge ? "Next Game" : "Play Again")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 120)
                    .padding()
                    .background(
                        LinearGradient(
                            colors: isInDailyChallenge ? [.blue, .purple] : [.green, .blue],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .cornerRadius(15)
                }
                .scaleEffect(buttonScale)
                .rotationEffect(.degrees(buttonRotation))
            }
        }
        .padding(30)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.2), radius: 10)
    }
    
    var body: some View {
        VStack(spacing: 30) {
            // Navigation and Title
            HStack {
                Button(action: { dismiss() }) {
                    Image(systemName: "arrow.left.circle.fill")
                        .font(.title2)
                        .foregroundColor(.purple)
                }
                .padding()
                Spacer()
            }
            
            Text("Time: \(gameState.timeRemaining)")
                .font(.title)
            
            Text("Score: \(gameState.score)")
                .font(.title)
            
            if gameState.isActive {
                Text(currentProblem)
                    .font(.system(size: 30))
                    .bold()
                
                // Answer options
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 20) {
                    ForEach(options, id: \.self) { option in
                        Button(action: { checkAnswer(option) }) {
                            Text("\(option)")
                                .font(.title)
                                .frame(maxWidth: .infinity)
                                .padding()
                                .background(Color.purple.opacity(0.1))
                                .cornerRadius(10)
                        }
                    }
                }
                .padding()
            } else {
                // Break up the complex expression
                let difficultyControl = GradientSegmentedControl(selection: $selectedDifficulty)
                    .padding()
                
                difficultyControl
                
                Button("Start Game") {
                    startGame()
                }
                .font(.title2)
                .foregroundColor(.white)
                .padding()
                .background(Color.purple)
                .cornerRadius(10)
            }
        }
        .padding()
        .overlay {
            if showGameOver {
                Color.black.opacity(0.5)
                    .ignoresSafeArea()
                    .overlay(gameOverAlert)
                    .transition(.opacity)
            }
        }
    }
    
    @MainActor
    private func startGame() {
        let settings = getDifficultySettings()
        gameState.timeRemaining = settings.timeLimit
        gameState.score = 0
        gameState.isActive = true
        generateNewProblem()
        
        Task {
            while gameState.timeRemaining > 0 && gameState.isActive {
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                gameState.timeRemaining -= 1
            }
            endGame()
        }
    }
    
    private func generateNewProblem() {
        let operations = ["+", "-", "×"]
        let operation = operations.randomElement()!
        let num1 = Int.random(in: 1...20)
        let num2 = Int.random(in: 1...20)
        
        switch operation {
        case "+":
            currentProblem = "\(num1) + \(num2)"
            correctAnswer = num1 + num2
        case "-":
            currentProblem = "\(num1) - \(num2)"
            correctAnswer = num1 - num2
        case "×":
            currentProblem = "\(num1) × \(num2)"
            correctAnswer = num1 * num2
        default:
            break
        }
        
        generateOptions()
    }
    
    private func generateOptions() {
        var newOptions = [correctAnswer]
        while newOptions.count < 4 {
            let option = correctAnswer + Int.random(in: -10...10)
            if option != correctAnswer && !newOptions.contains(option) {
                newOptions.append(option)
            }
        }
        options = newOptions.shuffled()
    }
    
    @MainActor
    private func checkAnswer(_ answer: Int) {
        if answer == correctAnswer {
            gameState.score += 10
            generateNewProblem()
        } else if gameState.score > 0 {
            gameState.score -= 5
        }
    }
    
    @MainActor
    private func endGame() {
        gameState.isActive = false
        showGameOver = true
        scoreManager.addScore(gameState.score, for: "Speed Logic")
        if isInDailyChallenge {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                dismiss()
            }
        }
    }
}

// MARK: - Pattern Match Game
struct PatternMatchGame: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var scoreManager: GameScoreManager
    @StateObject private var gameState = GameState()
    @State private var pattern: [Int] = []
    @State private var userPattern: [Int] = []
    @State private var showingPattern = false
    @State private var currentShowingIndex = -1
    @State private var showGameOver = false
    @State private var level = 1
    @Binding var selectedGame: Game?
    @State private var buttonScale = 1.0
    @State private var buttonRotation = 0.0
    @State private var selectedDifficulty: GameDifficulty = .easy
    
    let colors: [Color] = [.red, .blue, .green, .yellow]
    
    var isInDailyChallenge: Bool {
        scoreManager.scores.isEmpty
    }
    
    var gameOverAlert: some View {
        VStack(spacing: 20) {
            Text("Game Complete!")
                .font(.title2)
                .bold()
                .foregroundColor(.purple)
            
            Text("Score: \(gameState.score)")
                .font(.title3)
                .foregroundColor(.secondary)
            
            HStack(spacing: 20) {
                Button(action: { dismiss() }) {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                        Text("Exit")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 120)
                    .padding()
                    .background(Color.red.opacity(0.8))
                    .cornerRadius(15)
                }
                .scaleEffect(buttonScale)
                
                Button(action: {
                    withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) {
                        buttonScale = 1.2
                        buttonRotation += 360
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        if isInDailyChallenge {
                            scoreManager.addScore(gameState.score, for: "Pattern Match")
                            dismiss()
                        } else {
                            resetGame()
                            showGameOver = false
                        }
                    }
                    
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.6).delay(0.3)) {
                        buttonScale = 1.0
                    }
                }) {
                    HStack {
                        Image(systemName: isInDailyChallenge ? "arrow.right.circle.fill" : "arrow.clockwise.circle.fill")
                        Text(isInDailyChallenge ? "Next Game" : "Play Again")
                    }
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 120)
                    .padding()
                    .background(
                        LinearGradient(
                            colors: isInDailyChallenge ? [.blue, .purple] : [.green, .blue],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .cornerRadius(15)
                }
                .scaleEffect(buttonScale)
                .rotationEffect(.degrees(buttonRotation))
            }
        }
        .padding(30)
        .background(Color(UIColor.systemBackground))
        .cornerRadius(20)
        .shadow(color: Color.black.opacity(0.2), radius: 10)
    }
    
    var body: some View {
        VStack {
            // Navigation and Title
            HStack {
                Button(action: { dismiss() }) {
                    Image(systemName: "arrow.left.circle.fill")
                        .font(.title2)
                        .foregroundColor(.purple)
                }
                .padding(.horizontal)  // Add horizontal padding
                
                GameHeaderView(gameName: "Pattern Match")
            }
            .padding(.vertical, 8)  // Add vertical padding
            
            // Score and Level display
            HStack {
                Text("Score: \(gameState.score)")
                    .font(.title)
                Spacer()
                Text("Level: \(level)")
                    .font(.title)
            }
            .padding()
            
            // Game Grid
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach(0..<4) { index in
                    Button(action: { handleTap(index) }) {
                        RoundedRectangle(cornerRadius: 15)
                            .fill(colors[index])
                            .opacity(currentShowingIndex == index ? 1 : 0.7)
                            .frame(height: 150)
                            .scaleEffect(currentShowingIndex == index ? 1.1 : 1.0)
                    }
                    .disabled(showingPattern)
                }
            }
            .padding()
            
            if !gameState.isActive {
                // Break up the complex expression into smaller parts
                let difficultySelector = GradientSegmentedControl(selection: $selectedDifficulty)
                    .padding()
                
                VStack {
                    difficultySelector
                    
                    Button("Start Game") {
                        startGame()
                    }
                    .font(.title2)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.purple)
                    .cornerRadius(10)
                }
            }
        }
        .overlay {
            if showGameOver {
                Color.black.opacity(0.5)
                    .ignoresSafeArea()
                    .overlay(gameOverAlert)
                    .transition(.opacity)
            }
        }
    }
    
    private func startGame() {
        _ = getDifficultySettings()
        gameState.isActive = true
        gameState.score = 0
        level = 1
        generateNewPattern()
    }
    
    private func generateNewPattern() {
        pattern = (0..<level).map { _ in Int.random(in: 0..<4) }
        userPattern = []
        showingPattern = true
        currentShowingIndex = -1
        
        showPatternSequence()
    }
    
    private func showPatternSequence() {
        var index = 0
        
        func showNextColor() {
            if index < pattern.count {
                withAnimation {
                    currentShowingIndex = pattern[index]
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    withAnimation {
                        currentShowingIndex = -1
                    }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                        index += 1
                        showNextColor()
                    }
                }
            } else {
                showingPattern = false
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            showNextColor()
        }
    }
    
    private func handleTap(_ index: Int) {
        guard !showingPattern else { return }
        
        userPattern.append(index)
        
        if userPattern.count == pattern.count {
            if userPattern == pattern {
                // Correct pattern
                gameState.score += level * 10
                level += 1
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    generateNewPattern()
                }
            } else {
                // Wrong pattern
                endGame()
            }
        } else if userPattern.count <= pattern.count {
            // Check if the pattern is correct so far
            if pattern[userPattern.count - 1] != index {
                endGame()
            }
        }
    }
    
    private func endGame() {
        gameState.isActive = false
        showGameOver = true
        
        let finalScore = gameState.score
        scoreManager.scores.removeAll()
        scoreManager.addScore(finalScore, for: "Pattern Match")
        
        if isInDailyChallenge {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                dismiss()
            }
        }
    }
    
    private func resetGame() {
        gameState.isActive = false
        gameState.score = 0
        level = 1
        pattern = []
        userPattern = []
        showingPattern = false
        currentShowingIndex = -1
    }
    
    // Add difficulty settings
    private func getDifficultySettings() -> (timeLimit: Int, targetScore: Int) {
        switch selectedDifficulty {
        case .easy:
            return (timeLimit: 60, targetScore: 100)
        case .medium:
            return (timeLimit: 45, targetScore: 150)
        case .hard:
            return (timeLimit: 30, targetScore: 200)
        }
    }
}

// MARK: - Mind Missions View
struct MindMissionsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var scoreManager: GameScoreManager
    @State private var selectedMission: Mission?
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var showReward = false
    
    let missions = [
        Mission(
            id: 1,
            title: "Memory Master",
            description: "Complete Memory Match and Pattern Match games to enhance your memory and concentration",
            games: [
                Game(id: 1, name: "Memory Match", description: "Test your memory", icon: "brain"),
                Game(id: 3, name: "Pattern Match", description: "Improve focus through pattern recognition", icon: "puzzlepiece.fill")
            ],
            targetScore: 150,
            reward: "🏆 Memory Master Badge"
        ),
        Mission(
            id: 2,
            title: "Speed Champion",
            description: "Master Speed Logic and Quick React games to improve your processing speed",
            games: [
                Game(id: 2, name: "Speed Logic", description: "Enhance logical thinking", icon: "bolt"),
                Game(id: 4, name: "Quick React", description: "Test reaction time", icon: "timer")
            ],
            targetScore: 160,
            reward: "⚡️ Speed Champion Badge"
        ),
        Mission(
            id: 3,
            title: "Ultimate Challenge",
            description: "Complete all games with high scores to prove your cognitive mastery",
            games: [
                Game(id: 1, name: "Memory Match", description: "Test your memory", icon: "brain"),
                Game(id: 2, name: "Speed Logic", description: "Enhance logical thinking", icon: "bolt"),
                Game(id: 3, name: "Pattern Match", description: "Improve focus through pattern recognition", icon: "puzzlepiece.fill"),
                Game(id: 4, name: "Quick React", description: "Test reaction time", icon: "timer")
            ],
            targetScore: 300,
            reward: "🎯 Cognitive Master Badge"
        )
    ]
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    ForEach(missions) { mission in
                        NavigationLink {
                            MissionDetailView(mission: mission)
                                .environmentObject(scoreManager)
                        } label: {
                            MissionCard(mission: mission, onSelect: {})
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
            }
            .padding()
        }
        .navigationTitle("Mind Missions")
    }
}

struct MissionCard: View {
    let mission: Mission
    let onSelect: () -> Void
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Text(mission.title)
                    .font(.title2)
                    .bold()
                Spacer()
                Text(mission.reward)
                    .font(.title3)
            }
            
            Text(mission.description)
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            HStack {
                ForEach(mission.games) { game in
                    Label(game.name, systemImage: game.icon)
                        .font(.caption)
                        .padding(8)
                        .background(Color.purple.opacity(0.1))
                        .cornerRadius(8)
                }
            }
            
            Text("Target Score: \(mission.targetScore)")
                .font(.headline)
                .foregroundColor(.purple)
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 15)
                .fill(colorScheme == .dark ? Color.black.opacity(0.3) : Color.white)
                .shadow(color: Color.purple.opacity(0.2), radius: 10)
        )
    }
}

// MARK: - Game Progress View
struct GameProgressView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var scoreManager: GameScoreManager
    
    var gameScores: [(String, Int)] {
        let games = ["Memory Match", "Speed Logic", "Pattern Match", "Quick React"]
        return games.map { game in
            (game, scoreManager.getTotalScore(for: game))
        }
    }
    
    var body: some View {
        VStack {
            // Navigation button
            HStack {
                Spacer()
                Spacer()
            }
            
            List {
                Section(header: Text("Overall Progress")) {
                    VStack(spacing: 20) {
                        Text("\(scoreManager.getAllTimeTotal())")
                            .font(.system(size: 60, weight: .bold))
                        Text("Total Points")
                            .font(.headline)
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                }
                
                Section(header: Text("Game Statistics")) {
                    ForEach(gameScores, id: \.0) { game, score in
                        HStack {
                            Text(game)
                            Spacer()
                            Text("\(score) points")
                                .foregroundColor(.purple)
                        }
                    }
                }
                
                Section(header: Text("Recent Activity")) {
                    if scoreManager.scores.isEmpty {
                        Text("No games played yet")
                            .foregroundColor(.secondary)
                            .italic()
                    } else {
                        ForEach(Array(scoreManager.scores.prefix(5)).reversed()) { score in
                            HStack {
                                Text(score.gameName)
                                Spacer()
                                Text("+\(score.score)")
                                    .foregroundColor(.purple)
                            }
                        }
                    }
                }
            }
        }
        .navigationTitle("Progress")
    }
}

// MARK: - Fun Facts View
struct FunFactsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var currentFactIndex = 0
    @State private var showNewFact = false
    
    let facts = [
        Fact(title: "Brain Power",
             content: "Your brain uses about 20% of your body's total energy, despite only being 2% of your body weight.",
             icon: "brain.head.profile"),
        Fact(title: "Memory Capacity",
             content: "Your brain's storage capacity is considered virtually unlimited. It's estimated to be around 2.5 petabytes!",
             icon: "memorychip"),
        Fact(title: "Neural Speed",
             content: "Information travels through your neurons at speeds of up to 268 mph!",
             icon: "bolt.horizontal"),
        Fact(title: "Daily Thoughts",
             content: "The average person has about 70,000 thoughts per day.", icon:"bubble.left.and.bubble.right")
    ]
    
    var body: some View {
        VStack(spacing: 30) {
            // Navigation button
            HStack {
                Spacer()
            }
            
            Spacer()
            
            VStack(spacing: 20) {
                Image(systemName: facts[currentFactIndex].icon)
                    .font(.system(size: 60))
                    .foregroundColor(.purple)
                    .opacity(showNewFact ? 1 : 0)
                    .scaleEffect(showNewFact ? 1 : 0.5)
                
                Text(facts[currentFactIndex].title)
                    .font(.title2)
                    .bold()
                    .opacity(showNewFact ? 1 : 0)
                
                Text(facts[currentFactIndex].content)
                    .multilineTextAlignment(.center)
                    .padding()
                    .foregroundColor(.secondary)
                    .opacity(showNewFact ? 1 : 0)
            }
            .padding()
            .background(Color.purple.opacity(0.1))
            .cornerRadius(20)
            .padding()
            
            Spacer()
            
            Button(action: showNextFact) {
                Text("Next Fun Fact")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.purple)
                    .cornerRadius(10)
            }
            .padding()
        }
        .navigationTitle("Brain Facts")
        .onAppear {
            withAnimation(.spring()) {
                showNewFact = true
            }
        }
    }
    
    private func showNextFact() {
        withAnimation(.spring()) {
            showNewFact = false
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            currentFactIndex = (currentFactIndex + 1) % facts.count
            withAnimation(.spring()) {
                showNewFact = true
            }
        }
    }
}

// MARK: - Relax View
struct RelaxView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var breathingPhase = "Breathe In"
    @State private var isBreathingExerciseActive = false
    @State private var breathingProgress: CGFloat = 0
    
    var body: some View {
        VStack(spacing: 40) {
            // Navigation button
            HStack {
                
                Spacer()
            }
            
            Text(breathingPhase)
                .font(.largeTitle)
                .bold()
                .foregroundColor(.purple)
            
            ZStack {
                Circle()
                    .stroke(Color.purple.opacity(0.2), lineWidth: 20)
                    .frame(width: 250, height: 250)
                
                Circle()
                    .trim(from: 0, to: breathingProgress)
                    .stroke(Color.purple, lineWidth: 20)
                    .frame(width: 250, height: 250)
                    .rotationEffect(.degrees(-90))
                
                Image(systemName: "wind")
                    .font(.system(size: 60))
                    .foregroundColor(.purple)
            }
            
            Button(action: toggleBreathingExercise) {
                Text(isBreathingExerciseActive ? "Stop" : "Start Breathing Exercise")
                    .font(.title2)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.purple)
                    .cornerRadius(10)
                    .padding(.horizontal)
            }
        }
        .navigationTitle("Relax")
    }
    
    private func toggleBreathingExercise() {
        isBreathingExerciseActive.toggle()
        if !isBreathingExerciseActive {
            breathingProgress = 0
            breathingPhase = "Breathe In"
        } else {
            startBreathingExercise()
        }
    }
    
    private func startBreathingExercise() {
        withAnimation(.easeInOut(duration: 4)) {
            breathingProgress = 1
            breathingPhase = "Hold"
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
            if isBreathingExerciseActive {
                withAnimation(.easeInOut(duration: 4)) {
                    breathingProgress = 0
                    breathingPhase = "Breathe Out"
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                    if isBreathingExerciseActive {
                        startBreathingExercise()
                    }
                }
            }
        }
    }
}

// MARK: - Greeting View
struct GreetingView: View {
    @Binding var showGreeting: Bool
    @State private var opacity = 0.0
    @State private var scale = 0.5
    @State private var titleOffset: CGFloat = -50
    @State private var subtitleOffset: CGFloat = 50
    @State private var buttonScale = 0.1
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        ZStack {
            (colorScheme == .dark ? Color.purple.opacity(0.2) : Color.purple.opacity(0.1))
                .ignoresSafeArea()
            
            VStack(spacing: 30) {
                VStack(spacing: 20) {
                    Text("Hello! 👋")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundStyle(
                            LinearGradient(
                                colors: colorScheme == .dark ?
                                [.purple.opacity(0.8), .blue.opacity(0.8)] :
                                    [.purple, .blue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                    
                    Text("Welcome to MindGym")
                        .font(.title)
                        .foregroundColor(colorScheme == .dark ? .white : .primary)
                }
                
                VStack(spacing: 15) {
                    Text("Your Personal Brain Training Center")
                        .font(.title2)
                        .foregroundColor(colorScheme == .dark ? .white : .secondary)
                        .multilineTextAlignment(.center)
                    
                    Text("Scientifically designed exercises to enhance:")
                        .font(.headline)
                        .foregroundColor(colorScheme == .dark ? .white.opacity(0.9) : .secondary)
                    
                    HStack(spacing: 20) {
                        ForEach(["🧠 Memory", "⚡️ Focus", "🎯 Reaction", "🤔 Logic"], id: \.self) { skill in
                            Text(skill)
                                .font(.subheadline)
                                .padding(8)
                                .background(
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(colorScheme == .dark ?
                                              Color.purple.opacity(0.3) :
                                                Color.purple.opacity(0.1))
                                )
                        }
                    }
                    .padding(.top, 5)
                }
                .offset(y: subtitleOffset)
                
                Button(action: {
                    withAnimation(.spring()) {
                        showGreeting = false
                    }
                }) {
                    Text("Start Your Brain Training")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(width: 250)
                        .padding()
                        .background(
                            LinearGradient(
                                colors: [.purple, .blue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .cornerRadius(15)
                }
                .scaleEffect(buttonScale)
            }
            .padding()
        }
        .onAppear {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.7)) {
                titleOffset = 0
                opacity = 1.0
            }
            
            withAnimation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.3)) {
                subtitleOffset = 0
            }
            
            withAnimation(.spring(response: 0.8, dampingFraction: 0.7).delay(0.6)) {
                buttonScale = 1.0
            }
        }
    }
}

// MARK: - Feature Overview View
struct FeatureOverviewView: View {
    @Binding var showFeatureOverview: Bool
    @State private var currentFeatureIndex = 0
    @State private var isAnimating = false
    @Environment(\.colorScheme) private var colorScheme
    
    let features = [
        (title: "Brain Training Games",
         description: "Scientifically designed puzzles that target specific cognitive functions. Regular practice can improve memory retention, problem-solving skills, and mental agility.",
         benefits: ["Enhanced memory capacity", "Faster mental processing", "Better problem-solving"],
         icon: "brain.head.profile"),
        
        (title: "Daily Challenges",
         description: "Structured daily exercises that progressively increase in difficulty. Consistent training leads to improved cognitive performance and mental flexibility.",
         benefits: ["Progressive difficulty", "Structured learning", "Daily improvement tracking"],
         icon: "calendar"),
        
        (title: "Track Your Progress",
         description: "Detailed analytics and performance tracking help you understand your cognitive strengths and areas for improvement. Watch your brain power grow over time.",
         benefits: ["Performance analytics", "Improvement visualization", "Personalized insights"],
         icon: "chart.line.uptrend.xyaxis"),
        
        (title: "Mindful Relaxation",
         description: "Balance intense brain training with relaxation exercises. Reduce mental fatigue and enhance focus through guided breathing and meditation.",
         benefits: ["Stress reduction", "Better focus", "Mental recovery"],
         icon: "leaf")
    ]
    
    var body: some View {
        ZStack {
            (colorScheme == .dark ? Color.purple.opacity(0.2) : Color.purple.opacity(0.1))
                .ignoresSafeArea()
            
            VStack(spacing: 30) {
                Text("How MindGym Works")
                    .font(.title)
                    .bold()
                    .foregroundStyle(
                        LinearGradient(
                            colors: colorScheme == .dark ?
                            [.purple.opacity(0.8), .blue.opacity(0.8)] :
                                [.purple, .blue],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                
                
                TabView(selection: $currentFeatureIndex) {
                    ForEach(0..<features.count, id: \.self) { index in
                        VStack(spacing: 20) {
                            Image(systemName: features[index].icon)
                                .font(.system(size: 60))
                                .foregroundColor(colorScheme == .dark ? .white : .purple)
                                .padding()
                                .background(
                                    Circle()
                                        .fill(colorScheme == .dark ?
                                              Color.purple.opacity(0.3) :
                                                Color.purple.opacity(0.1))
                                )
                                .rotationEffect(Angle(degrees: isAnimating ? 360 : 0))
                                .animation(
                                    Animation.linear(duration: 2)
                                        .repeatForever(autoreverses: false),
                                    value: isAnimating
                                )
                            
                            Text(features[index].title)
                                .font(.title2)
                                .bold()
                                .foregroundColor(colorScheme == .dark ? .white : .primary)
                            
                            Text(features[index].description)
                                .multilineTextAlignment(.center)
                                .foregroundColor(colorScheme == .dark ? .white.opacity(0.8) : .secondary)
                                .padding(.horizontal)
                            
                            VStack(alignment: .leading, spacing: 10) {
                                Text("Benefits:")
                                    .font(.headline)
                                    .foregroundColor(colorScheme == .dark ? .white : .primary)
                                
                                ForEach(features[index].benefits, id: \.self) { benefit in
                                    HStack {
                                        Image(systemName: "checkmark.circle.fill")
                                            .foregroundColor(.green)
                                        Text(benefit)
                                            .foregroundColor(colorScheme == .dark ? .white.opacity(0.8) : .secondary)
                                    }
                                    .opacity(isAnimating ? 1 : 0)
                                    .offset(x: isAnimating ? 0 : -20)
                                    .animation(
                                        .easeOut(duration: 0.5)
                                        .delay(Double(features[index].benefits.firstIndex(of: benefit)!) * 0.2),
                                        value: isAnimating
                                    )
                                }
                            }
                            .padding(.horizontal)
                        }
                        .tag(index)
                        .transition(.slide)
                        .background(
                            RoundedRectangle(cornerRadius: 20)
                                .fill(colorScheme == .dark ?
                                      Color.black.opacity(0.3) :
                                        Color.white.opacity(0.7))
                                .shadow(color: Color.purple.opacity(0.2), radius: 10)
                        )
                        .padding(.horizontal)
                    }
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .automatic))
                .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
                
                Button(action: {
                    withAnimation {
                        showFeatureOverview = false
                    }
                }) {
                    Text(currentFeatureIndex == features.count - 1 ? "Let's Begin!" : "Skip")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(width: 200)
                        .padding()
                        .background(
                            LinearGradient(
                                colors: [.purple, .blue],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .cornerRadius(15)
                }
            }
            .padding()
        }
        .onAppear {
            isAnimating = true
        }
    }
}

// MARK: - Content View
struct ContentView: View {
    @StateObject private var scoreManager = GameScoreManager()
    @State private var selectedTab = 0
    @State private var showGreeting = true
    @State private var showFeatureOverview = true
    
    var body: some View {
        ZStack {
            NavigationView {
                TabView(selection: $selectedTab) {
                    GamesView()
                        .tabItem {
                            Image(systemName: "brain.head.profile")
                            Text("Games")
                        }
                        .tag(0)
                    
                    MindMissionsView()
                        .tabItem {
                            Image(systemName: "calendar")
                            Text("Daily")
                        }
                        .tag(1)
                    
                    GameProgressView()
                        .tabItem {
                            Image(systemName: "chart.line.uptrend.xyaxis")
                            Text("Progress")
                        }
                        .tag(2)
                    
                    FunFactsView()
                        .tabItem {
                            Image(systemName: "lightbulb.fill")
                            Text("Fun Facts")
                        }
                        .tag(3)
                    
                    RelaxView()
                        .tabItem {
                            Image(systemName: "leaf")
                            Text("Relax")
                        }
                        .tag(4)
                }
                .accentColor(.purple)
            }
            .environmentObject(scoreManager)
            .opacity(showGreeting || showFeatureOverview ? 0 : 1)
            
            if showGreeting {
                GreetingView(showGreeting: $showGreeting)
                    .transition(.opacity)
            } else if showFeatureOverview {
                FeatureOverviewView(showFeatureOverview: $showFeatureOverview)
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut, value: showGreeting)
        .animation(.easeInOut, value: showFeatureOverview)
    }
}

// MARK: - Preview Provider
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

// MARK: - Game Title Header
struct GameTitleHeader: ToolbarContent {
    let gameName: String
    
    var body: some ToolbarContent {
        ToolbarItem(placement: .principal) {
            VStack {
                Text("Daily Challenge")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                Text(gameName)
                    .font(.headline)
                    .foregroundColor(.purple)
            }
        }
    }
}

// MARK: - Mission Detail View
struct MissionDetailView: View {
    let mission: Mission
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var scoreManager: GameScoreManager
    @State private var currentGameIndex = 0
    @State private var selectedGame: Game?
    @State private var missionScores: [String: Int] = [:]
    @State private var showCompletion = false
    @State private var isMissionActive = false
    @State private var isLoading = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Mission Header
                VStack(alignment: .leading, spacing: 10) {
                    Text(mission.title)
                        .font(.title)
                        .bold()
                    
                    Text(mission.description)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Text("Target Score: \(mission.targetScore)")
                        .font(.headline)
                        .foregroundColor(.purple)
                }
                .padding()
                
                // Games List with Progress
                ForEach(Array(mission.games.enumerated()), id: \.element.id) { index, game in
                    NavigationLink {
                        GameDetailView(game: game)
                            .environmentObject(scoreManager)
                            .onDisappear {
                                if isMissionActive {
                                    if let score = scoreManager.scores.last?.score {
                                        missionScores[game.name] = score
                                        
                                        if score > 0 {
                                            if currentGameIndex < mission.games.count - 1 {
                                                currentGameIndex += 1
                                            } else {
                                                checkMissionCompletion()
                                            }
                                        }
                                    }
                                }
                            }
                    } label: {
                        HStack {
                            Image(systemName: game.icon)
                                .font(.title2)
                                .foregroundColor(.purple)
                                .frame(width: 40)
                            
                            VStack(alignment: .leading) {
                                Text(game.name)
                                    .font(.headline)
                                Text(game.description)
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                            
                            Spacer()
                            
                            if let score = missionScores[game.name] {
                                Text("\(score) pts")
                                    .foregroundColor(score >= mission.targetScore/mission.games.count ? .green : .red)
                            }
                            
                            if isMissionActive && index == currentGameIndex {
                                Image(systemName: "play.circle.fill")
                                    .foregroundColor(.green)
                            }
                        }
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color.purple.opacity(isMissionActive && index == currentGameIndex ? 0.2 : 0.05))
                        )
                    }
                    .disabled(!isMissionActive)
                }
                .padding(.horizontal)
                
                Spacer(minLength: 20)
                
                // Mission Progress and Button
                VStack(spacing: 10) {
                    // Mission Progress
                    if isMissionActive {
                        let totalScore = missionScores.values.reduce(0, +)
                        Text("Current Score: \(totalScore)")
                            .font(.headline)
                        ProgressView(value: Double(totalScore), total: Double(mission.targetScore))
                            .tint(.purple)
                            .padding(.horizontal)
                    }
                    
                    // Start/Reset Mission Button
                    Button(action: {
                        if isMissionActive {
                            resetMission()
                        } else {
                            startMission()
                        }
                    }) {
                        Text(isMissionActive ? "Reset Mission" : "Start Mission")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(
                                LinearGradient(
                                    colors: [.purple, .blue],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .cornerRadius(10)
                    }
                    .padding()
                }
                .background(Color(UIColor.systemBackground))
                .padding(.bottom)
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .alert("Mission Complete!", isPresented: $showCompletion) {
            Button("OK", role: .cancel) {
                isMissionActive = false
            }
        } message: {
            let totalScore = missionScores.values.reduce(0, +)
            Text(totalScore >= mission.targetScore ?
                 "Congratulations! You've earned the \(mission.reward)\nTotal Score: \(totalScore)" :
                    "Keep practicing to reach the target score!\nCurrent Score: \(totalScore)")
        }
        .overlay(
            isLoading ?
                ProgressView()
                    .scaleEffect(1.5)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color.black.opacity(0.3))
                : nil
        )
    }
    
    private func startMission() {
        missionScores.removeAll()
        currentGameIndex = 0
        isMissionActive = true
        scoreManager.scores.removeAll()
    }
    
    private func resetMission() {
        missionScores.removeAll()
        currentGameIndex = 0
        isMissionActive = false
        scoreManager.scores.removeAll()
    }
    
    private func checkMissionCompletion() {
        let totalScore = missionScores.values.reduce(0, +)
        if totalScore >= mission.targetScore {
            showCompletion = true
        }
    }
}

// MARK: - Mission
struct Mission: Identifiable, Hashable {
    let id: Int
    let title: String
    let description: String
    let games: [Game]
    let targetScore: Int
    let reward: String
    var isCompleted: Bool = false
}

// Add this struct near other models
struct GameTutorial {
    let title: String
    let steps: [TutorialStep]
    
    struct TutorialStep {
        let image: String
        let title: String
        let description: String
    }
}

struct TutorialView: View {
    let tutorial: GameTutorial
    let onComplete: () -> Void
    @State private var currentStep = 0
    
    var body: some View {
        VStack(spacing: 30) {
            Text(tutorial.title)
                .font(.title2.bold())
                .foregroundColor(.purple)
            
            TabView(selection: $currentStep) {
                ForEach(tutorial.steps.indices, id: \.self) { index in
                    let step = tutorial.steps[index]
                    VStack(spacing: 20) {
                        Image(systemName: step.image)
                            .font(.system(size: 60))
                            .foregroundColor(.purple)
                        
                        Text(step.title)
                            .font(.title3.bold())
                        
                        Text(step.description)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.secondary)
                    }
                    .tag(index)
                    .padding()
                }
            }
            .tabViewStyle(.page)
            
            Button(action: onComplete) {
                Text("Got it!")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 200)
                    .padding()
                    .background(Color.purple)
                    .cornerRadius(15)
            }
        }
        .padding()
    }
}

enum GameDifficulty: String, CaseIterable {
    case easy = "Easy"
    case medium = "Medium"
    case hard = "Hard"
}

struct ConfettiView: View {
    let count: Int
    @State private var particles: [(Double, Double, Double)] = []
    
    var body: some View {
        TimelineView(.animation) { timeline in
            Canvas { context, size in
                for (x, y, angle) in particles {
                    context.fill(
                        Path(ellipseIn: CGRect(x: x * size.width,
                                             y: y * size.height,
                                             width: 10,
                                             height: 10)),
                        with: .color(.purple)
                    )
                    context.rotate(by: .degrees(angle))
                }
            }
        }
        .onAppear {
            particles = (0..<count).map { _ in
                (Double.random(in: 0...1),
                 Double.random(in: 0...0.2),
                 Double.random(in: 0...360))
            }
        }
    }
}

// First, add this helper struct for the gradient style
struct GradientSegmentedControl: View {
    @Binding var selection: GameDifficulty
    
    var body: some View {
        HStack(spacing: 0) {
            ForEach(GameDifficulty.allCases, id: \.self) { difficulty in
                Button(action: { selection = difficulty }) {
                    Text(difficulty.rawValue)
                        .font(.headline)
                        .padding(.vertical, 8)
                        .frame(maxWidth: .infinity)
                        .background(
                            LinearGradient(
                                colors: selection == difficulty ?
                                    difficulty.gradientColors :
                                    [Color.clear, Color.clear],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .foregroundColor(selection == difficulty ? .white : .purple)
                }
            }
        }
        .background(Color.purple.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 8))
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.purple.opacity(0.2), lineWidth: 1)
        )
        .padding(.horizontal)
    }
}

// Add gradient colors to GameDifficulty
extension GameDifficulty {
    var gradientColors: [Color] {
        switch self {
        case .easy:
            return [.green, .blue]
        case .medium:
            return [.blue, .purple]
        case .hard:
            return [.purple, .red]
        }
    }
}

struct GameSettings {
    var soundEnabled: Bool = true
    var hapticEnabled: Bool = true
    var showTutorials: Bool = true
    
    static let shared = GameSettings()
}

struct Achievement: Identifiable {
    let id: String
    let title: String
    let description: String
    let requirement: Int
    var isUnlocked: Bool = false
}

class AchievementManager: ObservableObject {
    @Published var achievements: [Achievement] = [
        Achievement(id: "first_win", title: "First Victory", description: "Complete your first game", requirement: 1),
        Achievement(id: "master", title: "Brain Master", description: "Score 1000 points total", requirement: 1000),
        // Add more achievements
    ]
    
    func checkAchievements(score: Int, gameType: String) {
        // Check and update achievements
    }
}

class StreakManager: ObservableObject {
    @Published var currentStreak: Int = 0
    @Published var lastPlayedDate: Date?
    
    func updateStreak() {
        // Update streak logic
    }
}

struct GameError: LocalizedError {
    let message: String
    var errorDescription: String? { message }
}

// Use in game logic
func handleError(_ error: Error) {
    _ = (error as? GameError)?.message ?? "An unexpected error occurred"
    // Show error alert
}

// Add this class to handle sound effects
class SoundManager {
    nonisolated(unsafe) static let shared = SoundManager()
    
    func playSuccess() {
        AudioServicesPlaySystemSound(1519) // Success sound
    }
    
    func playError() {
        AudioServicesPlaySystemSound(1521) // Error sound
    }
    
    func playTap() {
        AudioServicesPlaySystemSound(1104) // Tap sound
    }
}

// Add this class definition
class ImageCache: ObservableObject {
    @Published var cache: [String: Image] = [:]
    
    func getImage(named: String) -> Image? {
        return cache[named]
    }
    
    func setImage(_ image: Image, forKey: String) {
        cache[forKey] = image
    }
}





